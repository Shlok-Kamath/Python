import random
import my_module
integer=random.randint(1,10)

print(integer)


print(my_module.pie)