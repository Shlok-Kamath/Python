# Write your code below this line 👇

print('hello world\nhello world\nhello world')