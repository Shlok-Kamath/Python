#Write your code below this line 👇

statement=input('Enter something - ')
print(len(statement))







