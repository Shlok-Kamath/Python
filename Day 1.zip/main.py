# Write your code below this line 👇
print('Hello World')