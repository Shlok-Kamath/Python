name='Rama'
print(name)

name='Smaran'
print(name)

name=input('what is your name? ')
length=len(name)
print(length)