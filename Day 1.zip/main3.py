# Write your code below this line 👇

print('hello' +' ' + 'Rama')